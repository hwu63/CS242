package com.example.why.assignment3;

/**
 * Created by Why on 22/10/2017.
 */

public class Item_search {
    public Item_user user;
    public String name;
    public String repo_url;

}

